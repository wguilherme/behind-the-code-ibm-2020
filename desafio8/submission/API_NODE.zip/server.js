const express = require("express")
const app = express()
const multer = require("multer")
const upload = multer({ dest: "uploads/" })

const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

const ModelId = "f2a3ba28-1969-4d09-bb48-7d157f035c9d"
const nluApiKey = "a5rp1mAv0sHO4axYZsp-YjbbGgzEP3r_UPFRrm8NZmfV"
const nluUrl = "https://api.us-south.natural-language-understanding.watson.cloud.ibm.com/instances/6a931651-1484-4c73-be6d-217dd6339d05"


// NLU
const NaturalLanguageUnderstandingV1 = require('ibm-watson/natural-language-understanding/v1');
const { IamAuthenticator } = require('ibm-watson/auth');
const { text } = require("body-parser");

const naturalLanguageUnderstanding = new NaturalLanguageUnderstandingV1({
  version: '2020-08-01',
  authenticator: new IamAuthenticator({
    apikey: nluApiKey,
  }),
  serviceUrl: nluUrl,
});

app.post("/",  upload.any(), async (req, res) => {

  // carro selecionado
  let car = req.body.car

 
  // tabela com todos carros e características
  // se não tiver negativo não sugere
  //  se não encontrar entidade nenhuma, retornar vazio

  if(!req.body.text) {

    let audio = req.files[0].path;
    let textToAnalyze = await sst(audio)
    let resultNlu = await nlu(textToAnalyze)

    res.status(200).json(resultNlu)
    let response = await filterNlu(resultNlu) 
    
    response.recommendation = recommendCar(response);


    res.status(200).json(response)
 }
  else {

    console.log(req.body.text)
      
    let textToAnalyze = req.body.text

    let resultNlu = await nlu(textToAnalyze)    

    let response = await filterNlu(resultNlu)

    res.status(200).json(response)

   } 
 })

 
 async function sst(audioFile) {

   console.log('Processando STT')   

   const speech = require('@google-cloud/speech');
   const fs = require('fs');
   const client = new speech.SpeechClient();
   const fileName = audioFile;

   const file = await fs.readFileSync(fileName);
   const audioBytes = await file.toString('base64');
   const audio = {
     content: audioBytes,
   };
   const config = {
   //   encoding: 'FLAC',
   //   sampleRateHertz: 16000,
     languageCode: 'pt-BR[',
     audioChannelCount: 2
   };
   const request = {
     audio: audio,
     config: config,
   }; 

   const [response] = await client.recognize(request);
   const transcription = await response.results.map(result => result.alternatives[0].transcript).join('\n');


   console.log(`Transcription: ${transcription}`);
   
   return transcription

 }

 async function nlu(text){
  const analyzeParams = {

    'features': {
     'entities': {
        'sentiment':true,
        "model": ModelId,
        // 'limit':2
     },
    },
    'text': text
  };

  var nluObj;

  await naturalLanguageUnderstanding.analyze(analyzeParams)
  .then(analysisResults => {

    console.log('entrou no NLU')
    console.log(JSON.stringify(analysisResults, null, 2));

    nluObj = analysisResults;

    console.log('#2323', analysisResults);

  })
  .catch(err => {
    console.log('error:', err);
  });

  return nluObj;
 }

 async function filterNlu(nlu){

  let response = {};
  let filteredEntities = [];
  let entities = nlu.result.entities


if(entities){
  entities.forEach(e => {

    let entity = {
      entity: e.type,
      sentiment: e.sentiment.score,
      mention: e.text,
    }

    filteredEntities.push(entity)
          
});


}


  response.recommendation = ""
  response.entities = filteredEntities

  return response
 }

 async function recommendCar(response){
     // mais negativo
     let minor = 0;
     let minor2 = 0;
     let selected = {}

     response.entities.forEach(m => { 
        if(m.sentiment < minor){ 
          minor2 = minor
          minor = m.sentiment
          selected = m
        }

     })

    // dif de 0.1 ou empate
    // priorizar na ordem sugerida no github






     // se não tiver recomendação retorna vazio
 }


 app.listen(3050, () => console.log("Rodando na porta 3050..."))